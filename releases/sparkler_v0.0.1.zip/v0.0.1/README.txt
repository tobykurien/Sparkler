Sparkler web framework
======================

To get started, run ./scripts/sparkler.sh


